  Para ejecutar hacer ./bin/lifecycle -h
Este comando informa del uso del programa

  Para compilar hacer makefile
  Para limpiar los objetos hacer make clean y para limpiar los ejecutables hacer
make cleaner