#include <iostream>

int main () {
  int table_size_ = 12;
//   int num_sum{0};
//   int aux {0};
  int k = 42345431;
//   while ( k > 0) {
//     aux = k;
//     num_sum += aux;
//     k /= 10;
//     std::cout << num_sum << "  " << k << std::endl;
//   }
//   std::cout << num_sum % table_size_ << std::endl;
//   return (num_sum % table_size_);

//   srand(k);
//   std::cout << srand (k) << " " << rand() << "    " <<  rand() % table_size_ << std::endl;
//   return (rand() % table_size_);
}