  Para ejecutar hacer ./bin/ordination 
  Para compilar, estando en /Practica_5_ordination hacer make

  Este programa genera un vector y luego con distintos algoritmos ordena los 
distintos elementos del vector